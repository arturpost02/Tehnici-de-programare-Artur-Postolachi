"""Exemplele din fișă. O sursă indisponibilă nu oprește restul exemplelor."""
import requests
import httptools as h


def main():
    exemple = [
        (h.search, ({"q": "python", "page": "2"},)),
        (h.search, ({"q": "hello world & co"},)),
        (h.search_url, ({"q": "python", "page": "2"},)),
        (h.fetch_with_agent, ("MyBot/1.0",)), (h.default_agent, ()),
        (h.post_json, ({"name": "Ana", "age": 19, "tags": ["a", "b"]},)),
        (h.post_form, ({"user": "ana", "city": "Bălți"},)),
        *[(h.describe_status, (code,)) for code in (200, 404, 503)],
        (h.is_ok, (204,)), (h.is_ok, (500,)),
        (h.count_redirects, (3,)), (h.final_url, (2,)), (h.first_hop, (3,)),
        (h.cookie_demo, ("theme", "dark")), (h.no_session_demo, ("theme", "dark")),
        *[(h.report, (path,)) for path in h.PATHS],
        (h.check_login, ("admin", "secret")), (h.check_login, ("admin", "gresit")),
    ]
    for functie, args in exemple:
        try:
            print(f"{functie.__name__}{args!r} -> {functie(*args)!r}", flush=True)
        except (requests.RequestException, ValueError, KeyError) as error:
            print(f"{functie.__name__}: {type(error).__name__}: {error}", flush=True)


if __name__ == "__main__":
    main()
