# Laborator: funcții, metode și importuri pe web
# Student: Artur Postolachi

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 1
import requests
import urllib.request

print("Versiunea requests:", requests.__version__)

# Exercițiul 2: Două stiluri de import
import time

# Stilul 1: requests.get arată clar din ce bibliotecă vine funcția.
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Stilul 1 - Cod de stare:", response.status_code)

time.sleep(1)  # Pauză de o secundă între cereri.

# Stilul 2: importăm direct get, pentru apeluri mai scurte.
from requests import get

response = get(BASE_URL, timeout=TIMEOUT)
print("Stilul 2 - Cod de stare:", response.status_code)

# Exercițiul 3: Alias-uri
import requests as rq

time.sleep(1)

response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Exercițiul 3 - Cod de stare:", response.status_code)

# Exercițiul 4: Doar biblioteca standard
import ssl
from pathlib import Path
from urllib.error import HTTPError, URLError

time.sleep(1)

certificate_file = Path(__file__).with_name("cacert.pem")
context = ssl.create_default_context(cafile=str(certificate_file))

try:
    with urllib.request.urlopen(
        BASE_URL, timeout=TIMEOUT, context=context
    ) as response:
        print("Exercițiul 4 - Cod de stare:", response.status)
        html = response.read().decode("utf-8")
        print("Primele 200 de caractere:")
        print(html[:200])

except HTTPError as error:
    print("Exercițiul 4 - Eroare HTTP:", error.code)
    print("Primele 200 de caractere din răspunsul de eroare:")
    print(error.read().decode("utf-8", errors="replace")[:200])
    error.close()

except URLError as error:
    print("Eroare de conexiune:", error.reason)

# Serverul a returnat 403 pentru cererea urllib.
# Acest răspuns de eroare nu reprezintă pagina principală.

# Exercițiul 5: Priviți în interiorul unui modul
print("\nExercițiul 5 - Numele din modulul requests:")
print(dir(requests))

# get este o funcție: trimite o cerere GET.
# Session este o clasă: permite crearea unei sesiuni HTTP.
# exceptions este un modul: conține clasele de excepții.

# Exercițiul 6: Citiți documentația
print("\nExercițiul 6 - Documentația requests.get:")
help(requests.get)

# get transmite opțiunile suplimentare prin **kwargs.
# Documentația request explică parametrul timeout.
help(requests.request)

# timeout limitează așteptarea conexiunii și a datelor.
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Exercițiul 6 - Cod de stare:", response.status_code)

# Exercițiul 7: Cronometrarea unei cereri
time.sleep(1)

start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()

print("\nExercițiul 7:")
print("Durata totală:", round(end - start, 3), "secunde")
print("response.elapsed:",
      round(response.elapsed.total_seconds(), 3), "secunde")

# perf_counter măsoară durata întregului apel, inclusiv descărcarea corpului.
# response.elapsed măsoară timpul până la primirea antetelor răspunsului,
# fără descărcarea corpului. La redirecționări, se referă la răspunsul final.

# Exercițiul 8: Când un import eșuează
print("\nExercițiul 8:")

try:
    import bs4
    print("Modulul bs4 este instalat.")
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Verificați-vă:
# Modul = o unitate de cod Python, adesea un fișier .py.
# Pachet = grupează module și poate conține subpachete.
# Bibliotecă = o colecție de cod reutilizabil,
# care poate include mai multe module și pachete.