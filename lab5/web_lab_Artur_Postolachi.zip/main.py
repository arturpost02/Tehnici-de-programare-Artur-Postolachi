# Laborator: funcții, metode și importuri pe web
# Student: Artur Postolachi

import argparse
import time
import webtools
from webtools import get_title, security_headers, DEFAULT_HEADERS

# Exercițiul 45:
# O definiție locală get_title după import ar înlocui numele importat.
# Funcția originală ar rămâne accesibilă ca webtools.get_title.

# Exercițiul 48: Argumente din linia de comandă
parser = argparse.ArgumentParser(description="Analizează o pagină web.")
parser.add_argument("url", help="URL-ul paginii, inclusiv https://")
args = parser.parse_args()

print("Exercițiul 48:")
print("URL primit:", args.url)
print("Antete implicite:", DEFAULT_HEADERS)

response = webtools.fetch(args.url)
print("Cod de stare:", response.status_code)
print("Titlul paginii:", get_title(response.text))

time.sleep(1)
headers = security_headers(args.url)

for name, present in headers.items():
    print(f"{name}: {present}")

import csv
from datetime import datetime

# Exercițiul 49: Salvarea unui raport CSV
print("\nExercițiul 49:")

paths = ["/", "/robots.txt", "/sitemap.xml"]
results = webtools.check_paths(args.url, paths)
checked_at = datetime.now().isoformat()

with open("report.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["path", "status", "checked_at"])

    for path, status in results.items():
        writer.writerow([path, status, checked_at])
        print(f"{path} -> {status}")

print("Raport salvat în report.csv")

print("\nExercițiul 50:")
time.sleep(1)
webtools.site_report(args.url)