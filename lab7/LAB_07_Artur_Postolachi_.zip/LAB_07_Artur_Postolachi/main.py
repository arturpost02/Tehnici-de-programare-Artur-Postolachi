"""Bucla finală — partea 7b și bonusul pentru module."""
from httptools import PATHS, report


def main():
    rezultate = [{**report(path), "path": path} for path in PATHS]
    reusite = [r for r in rezultate if r["status"] == 200]
    for rezultat in sorted(reusite, key=lambda r: r["seconds"], reverse=True):
        print(f'{rezultat["path"]} -> 200, {rezultat["seconds"]:.2f} secunde')
    print(f"Reușite: {len(reusite)} | Eșuate: {len(rezultate) - len(reusite)}")


if __name__ == "__main__":
    main()
