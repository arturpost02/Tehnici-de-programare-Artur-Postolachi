# Laborator: funcții, metode și importuri pe web
# Student: Artur Postolachi

from urllib.parse import urlparse

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 35: Componentele unui URL
def show_url_parts(url):
    """Afișează componentele principale ale unui URL."""
    parts = urlparse(url)

    print("Protocol:", parts.scheme)
    print("Domeniu:", parts.netloc)
    print("Cale:", parts.path)
    print("Interogare:", parts.query)
    print("Fragment:", parts.fragment)


print("Exercițiul 35:")
show_url_parts("https://cybercor.org/path?x=1#top")

from urllib.parse import urlparse, urljoin

# Exercițiul 36: Construirea adreselor absolute
def show_absolute_urls(base):
    """Transformă trei căi relative în URL-uri absolute."""
    paths = ["/about", "contact.html", "../index.html"]

    for path in paths:
        print(path, "->", urljoin(base, path))


print("\nExercițiul 36:")
show_absolute_urls(BASE_URL)

# urljoin() combină adresa de bază cu o cale relativă.
# Nu trimite cereri către adresele rezultate.

import re
import requests

# Exercițiul 37: Extragerea linkurilor cu expresii regulate
def extract_links(html):
    """Extrage valorile href dintre ghilimele duble, fără duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    return sorted(set(links))


print("\nExercițiul 37:")
response = requests.get(BASE_URL, timeout=TIMEOUT)
response.raise_for_status()

links = extract_links(response.text)
print("Numărul de linkuri unice:", len(links))

for link in links:
    print(link)

# findall() returnează toate potrivirile expresiei regulate.
# set() elimină duplicatele, iar sorted() ordonează rezultatul.

# Exercițiul 38: Separarea linkurilor interne și externe
def split_links(links, domain):
    """Returnează două liste: URL-uri interne și externe."""
    internal = []
    external = []
    base = "https://" + domain + "/"

    for link in links:
        absolute_url = urljoin(base, link)
        parts = urlparse(absolute_url)

        if parts.scheme not in ("http", "https"):
            continue

        if parts.netloc == domain:
            internal.append(absolute_url)
        else:
            external.append(absolute_url)

    return internal, external


print("\nExercițiul 38:")
domain = urlparse(BASE_URL).netloc
internal_links, external_links = split_links(links, domain)

print("Linkuri interne:", internal_links)
print("Linkuri externe:", external_links)

# Comparăm domeniul fiecărui URL cu domeniul site-ului.
# Nu accesăm linkurile; analizăm doar adresele.

from html.parser import HTMLParser

# Exercițiul 39: Extragerea imaginilor cu HTMLParser
class ImageFinder(HTMLParser):
    """Colectează valorile src din etichetele img."""

    def __init__(self):
        """Inițializează parserul și lista imaginilor."""
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Înregistrează sursa fiecărei imagini."""
        if tag == "img":
            for name, value in attrs:
                if name == "src" and value:
                    self.images.append(value)


print("\nExercițiul 39:")

test_html = '''
<img src="/logo.png">
<IMG SRC="poza.jpg">
<img alt="Fără sursă">
<img src="https://cdn.example.com/banner.webp" />
'''

test_parser = ImageFinder()
test_parser.feed(test_html)
print("Imagini din test:", test_parser.images)

parser = ImageFinder()
parser.feed(response.text)

print("Numărul imaginilor din HTML:", len(parser.images))
for source in parser.images:
    print(source)

# feed() analizează HTML-ul și apelează automat handle_starttag().
# Nu descărcăm imaginile; extragem doar valorile atributelor src.

import hashlib
import time

# Exercițiul 40: Amprenta paginii
def page_fingerprint(url):
    """Returnează amprenta SHA-256 a conținutului paginii."""
    response = requests.get(url, timeout=TIMEOUT)
    response.raise_for_status()
    return hashlib.sha256(response.content).hexdigest()


print("\nExercițiul 40:")

fingerprint1 = page_fingerprint(BASE_URL)
time.sleep(1)
fingerprint2 = page_fingerprint(BASE_URL)

print("Prima amprentă:", fingerprint1)
print("A doua amprentă:", fingerprint2)
print("Amprente identice:", fingerprint1 == fingerprint2)

# Amprentele diferă dacă se schimbă conținutul primit:
# de exemplu, după actualizarea paginii sau din cauza datelor dinamice.

import json

# Exercițiul 41: Salvarea și citirea antetelor în JSON
print("\nExercițiul 41:")

with open("headers.json", "w", encoding="utf-8") as file:
    json.dump(dict(response.headers), file, indent=2)

with open("headers.json", "r", encoding="utf-8") as file:
    saved_headers = json.load(file)

print("Antetele au fost salvate în headers.json.")

# Căutăm antetul indiferent de folosirea literelor mari sau mici.
for name, value in saved_headers.items():
    if name.lower() == "content-type":
        print("Content-Type din fișier:", value)
        break

    import socket

    # Exercițiul 42: Interogare DNS
def resolve(hostname):
    """Returnează adresa IPv4 asociată unui domeniu."""
    return socket.gethostbyname(hostname)


print("\nExercițiul 42:")

hostname = urlparse(BASE_URL).hostname

try:
    ip_address = resolve(hostname)
    print("Domeniu:", hostname)
    print("Adresă IP:", ip_address)
except socket.gaierror as error:
    print("Eroare la rezolvarea DNS:", error)

import ssl
import certifi

# Exercițiul 43: Expirarea certificatului HTTPS
def cert_days_left(hostname):
    """Returnează numărul de zile întregi până la expirarea certificatului."""
    context = ssl.create_default_context(cafile=certifi.where())

    with socket.create_connection(
        (hostname, 443), timeout=TIMEOUT
    ) as connection:
        with context.wrap_socket(
            connection, server_hostname=hostname
        ) as secure_connection:
            certificate = secure_connection.getpeercert()

    expiration = ssl.cert_time_to_seconds(certificate["notAfter"])
    return int((expiration - time.time()) // 86400)


print("\nExercițiul 43:")

try:
    days_left = cert_days_left(urlparse(BASE_URL).hostname)
    print("Zile până la expirarea certificatului:", days_left)
except (OSError, ValueError) as error:
    print("Nu am putut verifica certificatul:", error)  

    