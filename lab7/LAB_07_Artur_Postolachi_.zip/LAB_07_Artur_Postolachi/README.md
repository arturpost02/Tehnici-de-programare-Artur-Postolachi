# LAB 7 — Trusa de unelte HTTP

Student: Artur Postolachi. Soluție pentru toate cele șapte părți și bonusul de autentificare/module.

## Instalare și rulare

Din acest folder:

```text
python -m pip install -r requirements.txt
python main.py
python demo.py
```

`python httptools.py` pornește și el bucla finală. Importarea modulelor nu trimite cereri.

## Ce conține codul

1. `search`, `search_url`: parametrii sunt trimiși prin `params=`, inclusiv spații și &.
2. `fetch_with_agent`, `default_agent`: User-Agent-ul văzut de server.
3. `post_json`, `post_form`: JSON și formular, cu păstrarea corectă a tipurilor/diacriticelor.
4. `describe_status`, `is_ok`: clasificarea răspunsului și tratarea HTTPError.
5. `count_redirects`, `final_url`, `first_hop`: istoricul și oprirea la prima redirecționare.
6. `cookie_demo`, `no_session_demo`: diferența dintre o sesiune persistentă și apeluri independente.
7. `report`: status, URL final, redirecționări, durată și Content-Type; timeout de 3 secunde. `main.py` sortează descrescător doar răspunsurile 200 și numără toate celelalte rezultate ca eșecuri.
8. `check_login`: autentificarea demonstrativă admin/secret; programul principal este separat în main.py.

`seconds` folosește `response.elapsed.total_seconds()`, conform fișei: măsoară răspunsul final până la anteturi, nu întregul lanț de redirecționări sau descărcarea corpului. Timeout-ul requests nu reprezintă un termen global pentru întregul lanț.

Funcțiile de date propagă erorile de rețea; demo.py le prinde și continuă. report() întoarce dicționarul de eroare cerut, iar is_ok/check_login întorc False la probleme de transport. Răspunsurile HTTP 404/500 sunt păstrate ca statusuri în report().

## Testare

```text
python -m pip install pytest
python -m pytest -q
```

Testele trimit cereri reale către un server local de test pentru parametri, anteturi, POST, statusuri, redirecționări, cookie-uri și autentificare. Timeout-ul și lipsa conexiunii sunt simulate controlat. Testele nu depind de disponibilitatea httpbin.org. Timpii și eventualele erori la serviciul public pot varia.

Enunțul original este inclus în PDF. Arhiva este pregătită local; publicarea pe GitHub necesită aprobarea ta.
