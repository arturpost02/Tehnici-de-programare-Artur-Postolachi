"""LAB 7 — Trusa de unelte HTTP. Părțile 1–7 și bonusul 8.

Funcțiile care întorc date propagă erorile de transport către apelant.
report(), is_ok() și check_login() le gestionează explicit.
"""
import requests

BASE = "https://httpbin.org"
PATHS = ["/get", "/redirect/2", "/delay/1", "/status/404", "/delay/5"]
TIMEOUT = 3


def _get(path, **kwargs):
    response = requests.get(BASE + path, timeout=TIMEOUT, **kwargs)
    response.raise_for_status()
    return response


# Partea 1: requests encodează corect spațiile, diacriticele și &.
def search(params):
    return _get("/get", params=params).json()["args"]


def search_url(params):
    return _get("/get", params=params).url


# Partea 2: citim antetul văzut efectiv de server.
def fetch_with_agent(agent):
    return _get("/headers", headers={"User-Agent": agent}).json()["headers"]["User-Agent"]


def default_agent():
    return _get("/headers").json()["headers"]["User-Agent"]


# Partea 3: JSON păstrează tipurile; un formular transmite câmpuri text.
def post_json(data):
    response = requests.post(BASE + "/post", json=data, timeout=TIMEOUT)
    response.raise_for_status()
    return response.json()["json"]


def post_form(data):
    response = requests.post(BASE + "/post", data=data, timeout=TIMEOUT)
    response.raise_for_status()
    return response.json()["form"]


def describe_status(code):
    response = requests.get(BASE + f"/status/{code}", timeout=TIMEOUT)
    status = response.status_code
    if 200 <= status < 300:
        return "succes"
    if 400 <= status < 500:
        return "eroare client"
    if 500 <= status < 600:
        return "eroare server"
    return "alt status"  # Fișa cere clasificarea familiilor 2xx, 4xx, 5xx.


def is_ok(code):
    try:
        response = requests.get(BASE + f"/status/{code}", timeout=TIMEOUT)
        response.raise_for_status()
        return True
    except requests.RequestException:
        return False


def count_redirects(n):
    return len(_get(f"/redirect/{n}").history)


def final_url(n):
    return _get(f"/redirect/{n}").url


def first_hop(n):
    return _get(f"/redirect/{n}", allow_redirects=False).headers.get("Location")


def cookie_demo(name, value):
    with requests.Session() as session:
        response = session.get(BASE + "/cookies/set", params={name: value}, timeout=TIMEOUT)
        response.raise_for_status()
        response = session.get(BASE + "/cookies", timeout=TIMEOUT)
        response.raise_for_status()
        return response.json()["cookies"]


def no_session_demo(name, value):
    _get("/cookies/set", params={name: value})
    return _get("/cookies").json()["cookies"]


def report(path):
    try:
        response = requests.get(BASE + path, timeout=3)
        # Un 404 este un răspuns HTTP valid pentru raport, nu eroare de transport.
        return {
            "status": response.status_code,
            "final_url": response.url,
            "redirects": len(response.history),
            "seconds": response.elapsed.total_seconds(),
            "content_type": response.headers.get("Content-Type", ""),
        }
    except requests.RequestException as error:
        return {"status": None, "error": f"{type(error).__name__}: {error}"}


def check_login(user, password):
    try:
        response = requests.get(BASE + "/basic-auth/admin/secret",
                                auth=(user, password), timeout=TIMEOUT)
        return response.status_code == 200
    except requests.RequestException:
        return False


def main():
    # Implementarea este în main.py, iar acest modul rămâne executabil separat.
    from main import main as run
    run()


if __name__ == "__main__":
    main()
