# Laborator: funcții, metode și importuri pe web
# Student: Artur Postolachi

import requests
import time
import json
import re
import socket
import ssl
import certifi
from urllib.parse import urlparse, urljoin


TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Artur-Postolachi"}


def fetch(url, timeout=TIMEOUT):
    """Trimite o cerere GET cu antetele implicite."""
    return requests.get(
        url,
        timeout=timeout,
        headers=DEFAULT_HEADERS,
    )


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP."""
    return fetch(url).status_code


def get_title(html):
    """Extrage titlul paginii din codul HTML."""
    start = html.find("<title>")
    if start == -1:
        return ""

    start += len("<title>")
    end = html.find("</title>", start)
    if end == -1:
        return ""

    return html[start:end].strip()


def security_headers(url):
    """Verifică prezența a cinci antete de securitate."""
    response = fetch(url)
    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    return {name: name in response.headers for name in names}


def score_headers(results):
    """Returnează numărul antetelor de securitate prezente."""
    return sum(results.values())


def check_paths(base, paths):
    """Returnează codul HTTP pentru fiecare cale verificată."""
    results = {}

    for path in paths:
        time.sleep(1)
        url = base.rstrip("/") + "/" + path.lstrip("/")
        results[path] = get_status(url)

    return results


def fetch_robots(base):
    """Returnează textul robots.txt sau None dacă nu este disponibil."""
    robots_url = urljoin(base, "/robots.txt")

    try:
        response = fetch(robots_url)
        response.raise_for_status()

        if "text/html" in response.headers.get("Content-Type", "").lower():
            return None

        return response.text
    except requests.RequestException:
        return None


def disallowed_paths(text):
    """Extrage căile ne goale din directivele Disallow."""
    paths = []

    if text is None:
        return paths

    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        name, separator, value = line.partition(":")

        if separator and name.lower() == "disallow":
            value = value.strip()
            if value:
                paths.append(value)

    return paths


def extract_links(html):
    """Extrage valorile href dintre ghilimele duble, fără duplicate."""
    return sorted(set(re.findall(r'href="([^"]+)"', html)))


def split_links(links, domain):
    """Separă legăturile HTTP și HTTPS în interne și externe."""
    internal = []
    external = []

    for link in links:
        absolute_url = urljoin("https://" + domain + "/", link)
        parts = urlparse(absolute_url)

        if parts.scheme not in ("http", "https"):
            continue

        if parts.netloc == domain:
            internal.append(absolute_url)
        else:
            external.append(absolute_url)

    return internal, external


def resolve(hostname):
    """Returnează adresa IPv4 a domeniului."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname):
    """Returnează zilele întregi până la expirarea certificatului."""
    context = ssl.create_default_context(cafile=certifi.where())

    with socket.create_connection(
        (hostname, 443), timeout=TIMEOUT
    ) as connection:
        with context.wrap_socket(
            connection, server_hostname=hostname
        ) as secure_connection:
            certificate = secure_connection.getpeercert()

    expiration = ssl.cert_time_to_seconds(certificate["notAfter"])
    return int((expiration - time.time()) // 86400)

def site_report(url):
    """Construiește, afișează și salvează raportul unui site."""
    response = fetch(url)
    final_url = response.url
    parts = urlparse(final_url)
    hostname = parts.hostname

    title = get_title(response.text)
    links = extract_links(response.text)

    # Transformăm legăturile relative folosind URL-ul final.
    absolute_links = [urljoin(final_url, link) for link in links]
    internal, external = split_links(absolute_links, parts.netloc)

    time.sleep(1)
    headers = security_headers(final_url)

    # Verificăm redirecționările pornind de la HTTP.
    http_url = urlparse(url)._replace(scheme="http").geturl()
    time.sleep(1)
    redirected = fetch(http_url)
    redirect_chain = [
        {"url": item.url, "status": item.status_code}
        for item in redirected.history
    ]
    redirect_chain.append({
        "url": redirected.url,
        "status": redirected.status_code,
    })

    time.sleep(1)
    robots = fetch_robots(final_url)

    # Păstrăm raportul chiar dacă verificarea DNS sau TLS eșuează.
    try:
        ip = resolve(hostname)
    except OSError as error:
        ip = f"Eroare: {error}"

    try:
        days_left = cert_days_left(hostname)
    except (OSError, ValueError) as error:
        days_left = f"Eroare: {error}"

    report = {
        "url": url,
        "status": response.status_code,
        "final_url": final_url,
        "title": title,
        "ip": ip,
        "redirect_chain": redirect_chain,
        "security_headers": headers,
        "header_score": f"{score_headers(headers)}/{len(headers)}",
        "certificate_days_left": days_left,
        "internal_links_count": len(set(internal)),
        "external_links_count": len(set(external)),
        "robots_available": robots is not None,
        "disallowed_paths": disallowed_paths(robots),
    }

    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(report, file, ensure_ascii=False, indent=4)

    print(json.dumps(report, ensure_ascii=False, indent=4))
    print("Raport salvat în report.json")

    return report
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))