# Laborator: funcții, metode și importuri pe web
# Student: Artur Postolachi

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 21: Funcție pentru o cerere GET
def fetch(url, timeout=10):
    """Trimite o cerere GET cu un timeout configurabil."""
    return requests.get(url, timeout=timeout)


print("Exercițiul 21:")
response = fetch(BASE_URL)
print("Cod de stare:", response.status_code)

# Exercițiul 22: Funcție care returnează codul de stare
def get_status(url):
    """Trimite o cerere GET și returnează codul de stare HTTP."""
    return fetch(url).status_code


print("\nExercițiul 22:")

for path in ["/", "/robots.txt", "/sitemap.xml"]:
    time.sleep(1)
    status = get_status(BASE_URL + path)
    print(path, "->", status)

    # Exercițiul 23: Parametru cu valoare implicită
print("\nExercițiul 23:")

time.sleep(1)
default_response = fetch(BASE_URL)
print("Timeout implicit (10 s):", default_response.status_code)

time.sleep(1)
try:
    short_response = fetch(BASE_URL, timeout=3)
    print("Timeout specificat (3 s):", short_response.status_code)
except requests.Timeout:
    print("Cererea cu timeout de 3 secunde a expirat.")

# Dacă omitem timeout, funcția folosește valoarea implicită 10.
# timeout=3 înlocuiește valoarea implicită pentru acel apel.

# Exercițiul 24: Funcție pentru extragerea titlului
def get_title(html):
    """Returnează titlul din HTML sau un șir gol dacă lipsește."""
    start = html.find("<title>")
    end = html.find("</title>")

    if start != -1 and end > start:
        return html[start + len("<title>"):end].strip()

    return ""


print("\nExercițiul 24:")
title = get_title(response.text)
print("Titlul paginii:", title)

# Exercițiul 25: Documentația funcției
print("\nExercițiul 25:")
help(get_title)

# help() afișează semnătura funcției și docstring-ul acesteia.

def get_status(url: str) -> int:
    """Primește un URL și returnează codul de stare HTTP."""
    return fetch(url).status_code

# Exercițiul 26: Adnotări de tip
print("\nExercițiul 26:")

try:
    print(get_status(123))
except requests.RequestException as error:
    print("Tipul erorii:", type(error).__name__)
    print("Mesaj:", error)

# Adnotările documentează tipurile, dar nu le impun la executare.
# Valoarea 123 ajunge la requests, care o respinge ca URL invalid.

# Exercițiul 27: Verificarea disponibilității unei pagini
def page_exists(url):
    """Returnează True pentru un răspuns 200, altfel False."""
    try:
        return fetch(url).status_code == 200
    except requests.RequestException:
        return False


print("\nExercițiul 27:")

time.sleep(1)
print("Pagina principală:", page_exists(BASE_URL))

time.sleep(1)
print("Domeniu inexistent:",
      page_exists("https://this-domain-does-not-exist.invalid"))

# Erorile de conexiune sunt tratate în interiorul funcției.
# Un răspuns 200 nu garantează că serverul afișează pagina dorită.

# Exercițiul 28: Verificarea mai multor căi
def check_paths(base, paths):
    """Returnează un dicționar cu fiecare cale și codul HTTP."""
    results = {}

    for path in paths:
        time.sleep(1)
        results[path] = get_status(base + path)

    return results


print("\nExercițiul 28:")
statuses = check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
print(statuses)

# Cheile dicționarului sunt căile, iar valorile sunt codurile HTTP.

# Exercițiul 29: Argumente numite și valoare implicită
def get_header(url, name, default="lipsește"):
    """Returnează valoarea unui antet sau valoarea implicită."""
    response = fetch(url)
    return response.headers.get(name, default)


print("\nExercițiul 29:")
time.sleep(1)

server = get_header(url=BASE_URL, name="Server")
print("Server:", server)

# Argumentele numite indică explicit parametrul care primește valoarea.
# Dacă antetul nu există, funcția returnează "lipsește".

# Exercițiul 30: Verificarea antetelor de securitate
def security_headers(url):
    """Returnează un dicționar care indică prezența antetelor."""
    response = fetch(url)

    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    results = {}
    for name in names:
        results[name] = name in response.headers

    return results


print("\nExercițiul 30:")
time.sleep(1)
header_results = security_headers(BASE_URL)

for name, present in header_results.items():
    print(name, "->", present)

    # Exercițiul 31: Calcularea scorului antetelor
def score_headers(results):
    """Returnează numărul antetelor prezente raportat la total."""
    present = sum(results.values())
    total = len(results)
    return f"{present}/{total}"


print("\nExercițiul 31:")
print("Scor antete:", score_headers(header_results))

# În calcule, True valorează 1, iar False valorează 0.
# Refolosim rezultatele funcției security_headers() din exercițiul 30.

# Exercițiul 32: Citirea și prelucrarea fișierului robots.txt
def fetch_robots(base):
    """Returnează textul robots.txt sau None dacă nu este disponibil."""
    try:
        response = fetch(base.rstrip("/") + "/robots.txt")
        response.raise_for_status()

        if "text/html" in response.headers.get("Content-Type", ""):
            return None

        return response.text
    except requests.RequestException:
        return None


def disallowed_paths(text):
    """Extrage valorile ne goale ale directivelor Disallow."""
    paths = []

    if text is None:
        return paths

    for line in text.splitlines():
        line = line.split("#", 1)[0].strip()
        name, separator, value = line.partition(":")

        if separator and name.lower() == "disallow":
            value = value.strip()
            if value:
                paths.append(value)

    return paths


print("\nExercițiul 32:")
time.sleep(1)
robots_text = fetch_robots(BASE_URL)

if robots_text is None:
    print("robots.txt indisponibil sau răspuns HTML.")
else:
    print("Conținut robots.txt:")
    print(robots_text)

print("Căi Disallow:", disallowed_paths(robots_text))

# Exercițiul 33: Număr variabil de argumente
def response_times(*urls):
    """Returnează un dicționar cu durata fiecărei cereri, în secunde."""
    results = {}

    for url in urls:
        time.sleep(1)
        start = time.perf_counter()
        fetch(url)
        results[url] = time.perf_counter() - start

    return results


print("\nExercițiul 33:")
times = response_times(BASE_URL, ECHO_URL + "/get")

for url, seconds in times.items():
    print(url, "->", round(seconds, 3), "secunde")

# *urls colectează argumentele poziționale într-un tuplu.
# Pauza de o secundă nu este inclusă în durata măsurată.

# Exercițiul 34: Număr variabil de argumente numite
def log(message, **details):
    """Afișează un mesaj împreună cu detalii numite."""
    parts = [message]

    for name, value in details.items():
        parts.append(f"{name}={value}")

    print(" | ".join(parts))


print("\nExercițiul 34:")
log("Verificare finalizată", url=BASE_URL, status=response.status_code)

# **details colectează argumentele numite într-un dicționar.
# print() afișează informații; return transmite o valoare apelantului.
# Funcția log() returnează implicit None.