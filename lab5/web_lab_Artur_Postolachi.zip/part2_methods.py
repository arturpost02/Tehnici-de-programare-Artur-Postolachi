# Laborator: funcții, metode și importuri pe web
# Student: Artur Postolachi

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests
import time

# Exercițiul 9: Elementele de bază ale răspunsului
response = requests.get(BASE_URL, timeout=TIMEOUT)

print("Cod de stare:", response.status_code)  # atribut
print("Răspuns OK:", response.ok)             # atribut
print("URL final:", response.url)             # atribut
print("Codificare:", response.encoding)       # atribut

# Exercițiul 10: Tratarea erorilor cu o metodă
print("\nExercițiul 10:")

try:
    response.raise_for_status()  # metodă
    print("Pagina principală nu are erori HTTP.")
except requests.HTTPError:
    print("Pagina principală a returnat:", response.status_code)

time.sleep(1)

try:
    missing_response = requests.get(
        BASE_URL + "/this-page-does-not-exist",
        timeout=TIMEOUT
    )
    print("Cod pentru pagina de test:", missing_response.status_code)
    missing_response.raise_for_status()
    print("Serverul nu a returnat o eroare HTTP pentru această adresă.")

except requests.HTTPError:
    print("Pagina de test a returnat o eroare HTTP. Programul continuă.")

except requests.RequestException as error:
    print("Nu s-a putut efectua cererea:", error)

    # Observație la exercițiul 10:
# Adresa de test a returnat 200, deci raise_for_status()
# nu a ridicat HTTPError în această rulare.

# Exercițiul 11: Toate antetele
print("\nExercițiul 11 - Antetele paginii principale:")

for name, value in response.headers.items():
    print(f"{name}: {value}")

    # Exercițiul 12: Citirea antetelor cu metoda get()
print("\nExercițiul 12:")
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type:", response.headers.get("content-type", "lipsește"))

# Numele antetelor HTTP nu țin cont de litere mari sau mici.
# Ultimele două apeluri returnează aceeași valoare.
# Dacă antetul nu există, get() returnează valoarea "lipsește". 

# Exercițiul 13: Înlănțuirea metodelor
print("\nExercițiul 13:")
count = response.text.lower().count("cyber")
print("Numărul de apariții ale cuvântului 'cyber':", count)

# lower() transformă textul în litere mici și returnează un șir.
# Pe acest șir apelăm count("cyber") pentru a număra aparițiile.

# Exercițiul 14: Extragerea titlului paginii
print("\nExercițiul 14:")
html = response.text

start = html.find("<title>")
end = html.find("</title>")

if start != -1 and end > start:
    title = html[start + len("<title>"):end].strip()
    print("Titlul paginii:", title)
else:
    print("Titlul nu a fost găsit.")

# find() returnează poziția textului căutat sau -1 dacă lipsește.
# Slicing extrage textul dintre etichetele <title> și </title>.
# strip() elimină spațiile și liniile goale de la extremități.

# Exercițiul 15: Analiza liniilor HTML
print("\nExercițiul 15:")
lines = response.text.splitlines()

print("Numărul de linii:", len(lines))

longest_line = max(lines, key=len, default="")
print("Lungimea celei mai lungi linii:", len(longest_line))

# splitlines() împarte textul într-o listă de linii.
# max(..., key=len) selectează linia cu cele mai multe caractere.
# default="" permite tratarea unui răspuns gol.

# Exercițiul 16: Verificarea protocolului HTTPS
print("\nExercițiul 16:")

if response.url.startswith("https://"):
    print("Conexiune securizată prin HTTPS.")
else:
    print("Conexiunea nu folosește HTTPS.")

# startswith() verifică dacă șirul începe cu prefixul indicat.
# HTTPS protejează conexiunea, dar nu garantează că site-ul este de încredere.

# Exercițiul 17: Istoricul redirecționărilor
print("\nExercițiul 17:")
time.sleep(1)

redirect_response = requests.get(
    "http://cybercor.org",
    timeout=TIMEOUT
)

for previous_response in redirect_response.history:
    print("Redirecționare:", previous_response.status_code,
          previous_response.url)

print("URL final:", redirect_response.url)
print("Cod final:", redirect_response.status_code)

# history conține răspunsurile intermediare ale redirecționărilor.
# Răspunsul final este păstrat în redirect_response.

# Exercițiul 18: Compararea cererilor HEAD și GET
print("\nExercițiul 18:")
time.sleep(1)

head_response = requests.head(
    BASE_URL,
    timeout=TIMEOUT,
    allow_redirects=True
)

print("HEAD - Cod de stare:", head_response.status_code)
print("HEAD - Lungimea corpului:", len(head_response.content), "octeți")
print("GET - Lungimea corpului:", len(response.content), "octeți")

# HEAD primește antetele, fără corpul răspunsului.
# GET primește atât antetele, cât și corpul răspunsului.
# Refolosim răspunsul GET obținut la exercițiul 9.

# Exercițiul 19: Cookie-urile răspunsului
print("\nExercițiul 19:")

if response.cookies:
    for cookie in response.cookies:
        print("Nume:", cookie.name, "| Secure:", cookie.secure)
else:
    print("Niciun cookie setat.")

# name reprezintă numele cookie-ului.
# secure arată dacă acesta trebuie trimis doar prin conexiuni securizate. 
# 
# # Exercițiul 20: Sesiune cu User-Agent personalizat
print("\nExercițiul 20:")
time.sleep(1)

with requests.Session() as session:
    session.headers.update({
        "User-Agent": "WebLab-Artur-Postolachi"
    })

    echo_response = session.get(
        ECHO_URL + "/headers",
        timeout=TIMEOUT
    )
    echo_response.raise_for_status()

    data = echo_response.json()
    print("User-Agent primit de server:",
          data["headers"].get("User-Agent", "lipsește"))

# Session păstrează setări comune între cereri.
# json() este o metodă care transformă răspunsul JSON în obiecte Python.
# response.text este un atribut care conține textul răspunsului. 
# 
