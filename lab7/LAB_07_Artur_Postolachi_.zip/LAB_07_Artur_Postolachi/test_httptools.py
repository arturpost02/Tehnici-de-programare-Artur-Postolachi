"""Teste cu cereri HTTP reale către un server local de test, nu httpbin public."""
import base64
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import parse_qs, urlsplit
from unittest.mock import patch
import pytest
import requests
import httptools as h
import main


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, data=None, status=200, headers=None):
        body=json.dumps(data or {}).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json')
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers()
        if status != 204: self.wfile.write(body)

    def do_GET(self):
        path=urlsplit(self.path).path
        args={k:v[0] for k,v in parse_qs(urlsplit(self.path).query).items()}
        if path=='/get': self.reply({'args':args})
        elif path=='/headers': self.reply({'headers':dict(self.headers)})
        elif path.startswith('/status/'): self.reply(status=int(path.rsplit('/',1)[1]))
        elif path.startswith(('/redirect/','/relative-redirect/')):
            n=int(path.rsplit('/',1)[1])
            self.reply(status=302,headers={'Location':f'/relative-redirect/{n-1}' if n>1 else '/get'})
        elif path=='/cookies/set':
            cookie=SimpleCookie()
            for k,v in args.items(): cookie[k]=v;cookie[k]['path']='/'
            self.reply(status=302,headers={'Set-Cookie':cookie.output(header='').strip(),'Location':'/cookies'})
        elif path=='/cookies':
            cookie=SimpleCookie(self.headers.get('Cookie',''))
            self.reply({'cookies':{k:v.value for k,v in cookie.items()}})
        elif path=='/basic-auth/admin/secret':
            expected='Basic '+base64.b64encode(b'admin:secret').decode()
            self.reply(status=200 if self.headers.get('Authorization')==expected else 401)
        else: self.reply(status=404)

    def do_POST(self):
        body=self.rfile.read(int(self.headers.get('Content-Length','0'))).decode()
        if self.headers.get('Content-Type')=='application/json': self.reply({'json':json.loads(body)})
        else: self.reply({'form':{k:v[0] for k,v in parse_qs(body).items()}})


@pytest.fixture
def server(monkeypatch):
    srv=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=srv.serve_forever,daemon=True);thread.start()
    monkeypatch.setattr(h,'BASE',f'http://127.0.0.1:{srv.server_port}')
    yield
    srv.shutdown();srv.server_close();thread.join()


def test_parametri_si_anteturi(server):
    args={'q':'hello world & co','page':'2'}
    assert h.search(args)==args
    assert parse_qs(urlsplit(h.search_url(args)).query)=={k:[v] for k,v in args.items()}
    assert h.fetch_with_agent('MyBot/1.0')=='MyBot/1.0'
    assert h.default_agent().startswith('python-requests/')


def test_post_tipuri_si_diacritice(server):
    data={'name':'Ana','age':19,'tags':['a','b']}
    assert h.post_json(data)==data
    assert h.post_form({'city':'Bălți'})=={'city':'Bălți'}


def test_statusuri(server):
    assert [h.describe_status(c) for c in (200,404,503)]==['succes','eroare client','eroare server']
    assert h.is_ok(204) is True
    assert h.is_ok(500) is False


def test_redirectari(server):
    assert h.count_redirects(3)==3
    assert h.final_url(2)==h.BASE+'/get'
    assert h.first_hop(3)=='/relative-redirect/2'


def test_cookie_si_login(server):
    assert h.cookie_demo('theme','dark')=={'theme':'dark'}
    assert h.no_session_demo('theme','dark')=={}
    assert h.check_login('admin','secret') is True
    assert h.check_login('admin','gresit') is False


def test_raport(server):
    r=h.report('/redirect/2')
    assert r['status']==200 and r['redirects']==2
    assert r['final_url']==h.BASE+'/get'
    assert isinstance(r['seconds'],float) and r['seconds']>=0
    assert r['content_type']=='application/json'
    assert h.report('/status/404')['status']==404


@pytest.mark.parametrize('error',[requests.Timeout('lent'),requests.ConnectionError('offline')])
def test_erori_retea(error):
    with patch.object(h.requests,'get',side_effect=error) as get:
        r=h.report('/delay/5')
        assert r['status'] is None and 'error' in r
        assert get.call_args.kwargs['timeout']==3
        assert h.is_ok(200) is False
        assert h.check_login('admin','secret') is False


def test_main_sorteaza_si_numara(capsys):
    results=[{'status':200,'seconds':.3},{'status':200,'seconds':.5},
             {'status':200,'seconds':1.1},{'status':404},{'status':None}]
    with patch.object(main,'report',side_effect=results): main.main()
    lines=capsys.readouterr().out.splitlines()
    assert [line.split(' ->')[0] for line in lines[:3]]==['/delay/1','/redirect/2','/get']
    assert lines[-1]=='Reușite: 3 | Eșuate: 2'
